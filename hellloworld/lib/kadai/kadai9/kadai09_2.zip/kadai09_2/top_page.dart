import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class TopPage extends StatelessWidget {
  const TopPage({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      appBar: AppBar(title: const Text('トップページ')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('メール: ${user?.email ?? "不明"}'),
            Text('UID: ${user?.uid ?? "不明"}'),
          ],
        ),
      ),
    );
  }
}

